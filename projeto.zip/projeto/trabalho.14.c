#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_VEICULOS 10
#define MAX_CLASSES 5

// estrutura de data e hora + porticos + veiculos
typedef struct DataHora
{
    int dia;
    int mes;
    int ano;
    int horas;
    int minutos;
} datahora;

typedef struct Portico
{
    int identf;
    char nome[50];
    float valor[5];
    float precosAntigos[5][5];
    int total_passagens;
} portico;

typedef struct Veiculo
{
    int classe;
    char matricula[10];
    int num_porticos;
    int porticos[4];
    datahora dh;
} veiculo;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Funções

// criar uma função que permita para além de dizer o número da classe , também imprima o nome do respetivo veículo
// estrutura de controlo de fluxo
const char *getNomeClasse(int numeroClasse)
{
    switch (numeroClasse)
    {
    case 1:
        return " Motociclo";
    case 2:
        return " Veículo Ligeiro";
    case 3:
        return " Veículo Pesado";
    case 4:
        return " Veículo Pesado com 4 Eixos";
    case 5:
        return " Aderente à Via Verde";
    default:
        return " Classe Inválida!";
    }
}

void imprimirTabelaPrecos(portico p)
{
    printf("### Tabela de Preços para o Pórtico %d - %s ###\n", p.identf, p.nome);
    for (int i = 0; i < MAX_CLASSES; ++i)
    {
        printf("  Classe %d: %.2f€\n", i + 1, p.valor[i]);
    }
    printf("______________________________________\n");
}

// informações para imprimir o veículo
void imprimirVeiculo(veiculo v, portico p[])
{
    printf("O seu carro com a matrícula: %s\nPassou às: %d:%d\nCom Data: %d/%d/%d\nNos pórticos: ", v.matricula, v.dh.horas, v.dh.minutos, v.dh.dia, v.dh.mes, v.dh.ano);

    for (int i = 0; i < v.num_porticos; ++i)
    {
        int porticoIndex = v.porticos[i] - 1;
        printf("%d (%s) ", p[porticoIndex].identf, p[porticoIndex].nome);
    }

    printf("\nTipo de classe do veículo: %d - %s\n", v.classe, getNomeClasse(v.classe));
}

void modificarPrecos(portico p[], int numPorticos)
{
    int numPortico;

    printf("Digite o número do pórtico para modificar os preços: ");
    scanf("%d", &numPortico);

    if (numPortico < 1 || numPortico > numPorticos)
    {
        printf("Número de pórtico inválido!\n");
        return;
    }

    // Copiar preços atuais para precosAntigos
    for (int i = 0; i < MAX_CLASSES; ++i)
    {
        p[numPortico - 1].precosAntigos[i][numPortico - 1] = p[numPortico - 1].valor[i];
    }

    printf("Novos preços para o pórtico %d - %s\n", p[numPortico - 1].identf, p[numPortico - 1].nome);
    for (int i = 0; i < MAX_CLASSES; ++i)
    {
        printf(" Insira o preço da passagem para a classe %d: ", i + 1);
        scanf("%f", &p[numPortico - 1].valor[i]);
    }

    printf("Preços modificados com sucesso!\n");
}

// Calculo do pagamento em que cada veículo passe por qualquer pórtico -- (faz o somatório dos pórticos que passou)
void calcularPagamento(veiculo v, portico p[])
{
    // Lógica de pagamento
    float pagamento = 0;

    for (int i = 0; i < v.num_porticos; ++i)
    {
        int porticoIndex = v.porticos[i] - 1;
        int classe = v.classe - 1;
        pagamento += p[porticoIndex].valor[classe];
    }

    printf("Pagamento total é: %.2f€\n", pagamento);
    printf("______________________________________\n");
}

// obrigar ao programa a colocar uma data e hora aleatória nas passagens dos pórticos
datahora gerarDataHoraAleatoria()
{
    datahora dh;

    // aleatório data e hora
    dh.dia = rand() % 30 + 1;   // Dia entre 1 e 30
    dh.mes = rand() % 12 + 1;   // Mês entre 1 e 12
    dh.ano = rand() % 3 + 2021; // Ano entre 2021 e 2023
    dh.horas = rand() % 24;     // Hora entre 0 e 23
    dh.minutos = rand() % 60;   // Minuto entre 0 e 59

    return dh;
}

// função para obter informações do veiculo - matricula/classe/nº de porticos que passou/quais os porticos que passou
void obterInformacoesVeiculo(veiculo *v, portico p[])
{
    printf(" Introduza a matrícula do veículo: ");
    scanf("%s", v->matricula);

    printf(" Introduza a classe do veículo (1 a 5): ");
    scanf("%d", &v->classe);

    printf(" Introduza o número de pórticos que o veículo passou: ");
    scanf("%d", &v->num_porticos);

    printf(" Introduza os identificadores dos pórticos separados por espaço: ");
    for (int j = 0; j < v->num_porticos; ++j)
    {
        scanf("%d", &v->porticos[j]);
    }

    // gerar aleatoriamente uma data e hora e imprimir
    v->dh = gerarDataHoraAleatoria();

    for (int j = 0; j < v->num_porticos; ++j)
    {
        int porticoIndex = v->porticos[j] - 1;
        p[porticoIndex].total_passagens++;
    }
}

void calcularRendimentoDiario(veiculo veiculos[], portico p[], int numVeiculos, int numPorticos)
{
    printf("### Rendimento Diário por Pórtico e Classe ###\n");
    for (int i = 0; i < numPorticos; ++i)
    {
        printf("%s:\n", p[i].nome);

        for (int j = 0; j < MAX_CLASSES; ++j)
        {
            float rendimentoDiario = 0;

            for (int k = 0; k < numVeiculos; ++k)
            {
                // verifica se o carro passou por esse portico e se pertence a classe atual
                for (int l = 0; l < veiculos[k].num_porticos; ++l)
                {
                    if (veiculos[k].porticos[l] == p[i].identf && veiculos[k].classe == (j + 1))
                    {
                        rendimentoDiario += p[i].valor[j];
                    }
                }
            }

            printf("  Classe %d: %.2f€\n", j + 1, rendimentoDiario);
        }
        printf("______________________________________\n");
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// ponto de entrada na execução do programa
int main()
{
    // inicia aleatoriamente os horarios
    srand(time(NULL));

    // valores por classe em cada portico 1 a 4
    portico porticos[] = {
        {1, "1 - Neiva", {0.40, 0.75, 1.0, 1.1, 0.3}},    // Pórtico 1 com valores para as 5 classes
        {2, "2 - Esposende", {0.70, 1.2, 1.5, 1.7, 0.5}}, // Pórtico 2 com valores para as 5 classes
        {3, "3 - Póvoa", {0.70, 1.3, 1.65, 1.8, 0.7}},    // Pórtico 3 com valores para as 5 classes
        {4, "4 - Angeiras", {0.55, 1.0, 1.25, 1.40, 0.9}} // Pórtico 4 com valores para as 5 classes
    };

    for (int i = 0; i < sizeof(porticos) / sizeof(porticos[0]); ++i)
    {
        porticos[i].total_passagens = 0;
    }

    veiculo veiculos[MAX_VEICULOS];
    int numVeiculos = 0;

    int opcao;

    // estrutura de controlo de fluxo
    do
    {
        printf("\n###### A28 - GESTOR ######\n");
        printf("## 1. Adicionar veículo ##\n");
        printf("## 2. Lista veículos    ##\n");
        printf("## 3. NºPassagem Pórtco ##\n");
        printf("## 4. Modificar Preços  ##\n");
        printf("## 5. Histórico Preços  ##\n");
        printf("## 6. Verificar€Tabela  ##\n");
        printf("## 7. Cálc. Rendimento  ##\n");
        printf("## 8. Sair              ##\n");
        printf("## Escolha uma opção    ##");
        printf("\n##########################\n");
        scanf("%d", &opcao);
        printf("______________________________________\n");

        switch (opcao)
        {
        case 1:
            if (numVeiculos < MAX_VEICULOS)
            {
                obterInformacoesVeiculo(&veiculos[numVeiculos], porticos);
                numVeiculos++;
                printf("Veículo adicionado com sucesso!\n");
            }
            else
            {
                printf("Limite de veículos atingido!\n");
            }
            break;

        case 2:
            for (int i = 0; i < numVeiculos; ++i)
            {
                imprimirVeiculo(veiculos[i], porticos);
                calcularPagamento(veiculos[i], porticos);
                printf("\n");
            }
            break;

        case 3:
            printf("### Número total de passagens por pórtico ###\n");
            for (int i = 0; i < sizeof(porticos) / sizeof(porticos[0]); ++i)
            {
                printf("%s: %d passagens\n", porticos[i].nome, porticos[i].total_passagens);
            }
            break;

        case 4:
            modificarPrecos(porticos, sizeof(porticos) / sizeof(porticos[0]));
            break;

        case 5:
            printf("### Histórico de Preços Antigos ###\n");
            for (int i = 0; i < sizeof(porticos) / sizeof(porticos[0]); ++i)
            {
                printf("Histórico de preços antigos para o pórtico %d - %s:\n", porticos[i].identf, porticos[i].nome);
                for (int j = 0; j < MAX_CLASSES; ++j)
                {
                    printf("  Classe %d: %.2f€\n", j + 1, porticos[i].precosAntigos[j][i]);
                }
            }
            break;

        case 6:
            for (int i = 0; i < sizeof(porticos) / sizeof(porticos[0]); ++i)
            {
                imprimirTabelaPrecos(porticos[i]);
            }
            break;

        case 7:
            calcularRendimentoDiario(veiculos, porticos, numVeiculos, sizeof(porticos) / sizeof(porticos[0]));
            break;

        case 8:
            printf("Saindo do programa. Até logo!\n");
            break;

        default:
            printf("Opção inválida! Tente novamente.\n");
        }

    } while (opcao != 8);

    return 0;
}